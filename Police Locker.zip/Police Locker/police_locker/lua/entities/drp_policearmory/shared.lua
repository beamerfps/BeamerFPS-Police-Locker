ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.PrintName = "Police Essentials Police Locker"

ENT.Author = "BeamerFPS"

ENT.Spawnable = true

ENT.Category = "Police Essentials"

ENT.AutomaticFrameAdvance = true