Police Locker is an addon for police officers to be able to either purchase or get Primaries,Secondaries,Armor,Health,Ammo and there uniform for free. 

Features
Custom Model
Custom Icons
Custom UI
Easy Config
Can customize everything
Be able to make police officer purchase the items or give it to them for free
Set Max Health
Set Max Armor
Purchase Cooldowns
Custom door animations


﻿Support/Suggestions
Do not add me on steam for support i will not add you.

You can join this discord for suggestions and i will help you in that discord also!
https://discord.gg/YcU5T33


you can edit the config by going to lua/autorun/sh_policelocker_config
